import React from 'react';
import './index.css';
import { FaUser, FaLock } from 'react-icons/fa';
import logo from './logo.png';

const SignInForm = () => {
  return (
    <div className="signin-container">
      <img src={logo} alt="Profile Avatar" className="avatar" />
      <h2 className="sign-in-heading">Login</h2>
      {/* <div className="social-icons">
        <a href="#" className="social-icon"><i className="fab fa-facebook-f"></i></a>
        <a href="#" className="social-icon"><i className="fab fa-twitter"></i></a>
      </div> */}
      <form>
        <div className="input-group">
          <div className="icon">
            <FaUser />
          </div>
          <input type="text" placeholder="Username" required />
        </div>
        <div className="input-group">
          <div className="icon">
            <FaLock />
          </div>
          <input type="password" placeholder="Password" required />
        </div>
        <div className="checkbox-group">
          <input type="checkbox" id="save-password" />
          <label htmlFor="save-password">Remember me</label>
        </div>
        <button type="submit" className="login-btn">Login</button>
      </form>
      <div className="extra-links">
        <a href="#" className="account-text">Don't have an account? <span className="inner-extra-links">Register Now!</span></a>
        <a href="#" className="password-text">Forgot Password</a>
      </div>
    </div>
  );
};

export default SignInForm;
