// import logo from './logo.svg';
import './App.css';
// import Login from './login';
// import Register from './register';
// import Navbar from './home';
// import Booking from './booking';
// import Rooms from './rooms';
// import GuestDetails from './guest-details';
// import Edit from './edit';
// import Home from './home';
// import RoomsCard from './room-cards';
function App() {
  return (
    <div className="App">
      {/* <Register /> */}
      {/* <Login /> */}
      {/* <Navbar /> */}
      {/* <Booking /> */}
      {/* <Rooms /> */}
      {/* <GuestDetails /> */}
      {/* <Home /> */}
      {/* <Edit /> */}
      {/* <RoomsCard /> */}
    </div>
  );
}

export default App;
