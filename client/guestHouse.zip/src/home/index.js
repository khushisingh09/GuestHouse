// App.js
import React from 'react';
import './index.css';

function App() {
  return (
    <div className="App">
      <header className="header">
        <div className="logo">Logo</div>
        <nav className="nav">
          <a href="#home">Home</a>
          <a href="#guest-registration">Guest Registration</a>
          <a href="#view-rooms">View Rooms</a>
          <a href="#booking-status">Booking Status</a>
          <a href="#about-us">About Us</a>
        </nav>
      </header>

      <main>
        <section className="hero">
          <div className="hero-content">Hero section features photos that is to be displayed</div>
          <div className="carousel-indicators">
            <span className="indicator"></span>
            <span className="indicator"></span>
            <span className="indicator"></span>
          </div>
        </section>
      </main>

      <footer>
        <div className="feedback">
          <button>Provide us your feedback</button>
        </div>
        <div className="quick-links">
          <h4>Quick Links</h4>
          <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#rooms">Rooms</a></li>
          </ul>
        </div>
        <div className="our-services">
          <h4>Our Services</h4>
          <ul>
            <li><a href="#catering-services">Catering Services</a></li>
            <li><a href="#conference-room">Conference Room</a></li>
          </ul>
        </div>
        <div className="location">
          <h4>Location</h4>
          <div className="map">Location Map</div>
        </div>
        <div className="social-media">
          <h4>Stay connected:</h4>
          <a href="#facebook" className="social-icon">FB</a>
          <a href="#instagram" className="social-icon">IG</a>
          <a href="#whatsapp" className="social-icon">WA</a>
          <a href="#email" className="social-icon">Email</a>
          <a href="#twitter" className="social-icon">Twitter</a>
        </div>
        <div className="copyright">
          <p>Copyright 2024 | All Rights Reserved by CIMFR</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
