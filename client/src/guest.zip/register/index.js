import React from 'react';
import './index.css';

const RegisterForm = () => {
  return (
    <div className="register-container">
      <form className="register-form">
        <h2>Register Now!</h2>
        {/* <p>Lorem ipsum dolor sit amet elit. Sapiente sit aut eos consectetur adipisicing.</p> */}
        <div className="form-row">
          <div className="form-group">
            <label htmlFor="employerId">Employer Id</label>
            <input type="text" id="employerId" placeholder="e.g. 12345" required />
          </div>
          <div className="form-group">
            <label htmlFor="idProof">ID Proof</label>
            <input type="text" id="idProof" placeholder="e.g. Aadhar Card Number" required />
          </div>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label htmlFor="firstName">First Name</label>
            <input type="text" id="firstName" placeholder="e.g. John" required />
          </div>
          <div className="form-group">
            <label htmlFor="lastName">Last Name</label>
            <input type="text" id="lastName" placeholder="e.g. Smith" required />
          </div>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label htmlFor="gender">Gender</label>
            <select id="gender" required>
              <option value="">Select</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="employeeType">Employee Type</label>
            <select id="employeeType" required>
              <option value="">Select</option>
              <option value="technicalOfficer">Technical Officer</option>
              <option value="projectAssociate">Project Associate</option>
              <option value="jrf">JRF</option>
              <option value="srf">SRF</option>
              <option value="researchScholar">Research Scholar</option>
              <option value="pensioner">Pensioner</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label htmlFor="phone">Phone No.</label>
            <input type="tel" id="phone" placeholder="+91 0000000000" required />
          </div>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input type="email" id="email" placeholder="e.g. john@your-domain.com" required />
          </div>
        </div>
        {/* <div className="form-group full-width">
          <label htmlFor="confirmPassword">Re-type Password</label>
          <input type="password" id="confirmPassword" placeholder="Your Password" required />
        </div> */}
        <div className="terms full-width">
          <input type="checkbox" id="terms" required />
          <label htmlFor="terms">
            Creating an account means you're okay with our <a href="#">Terms and Conditions</a> and our <a href="#">Privacy Policy</a>.
          </label>
        </div>
        <button type="submit">Register</button>
      </form>
    </div>
  );
};

export default RegisterForm;
